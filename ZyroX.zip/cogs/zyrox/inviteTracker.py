import discord

from discord.ext import commands

class inviteTracker(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    """Invite Tracker"""

    def help_custom(self):

              emoji = '<:zpeople:1448951456861519962>'

              label = "Invite Tracker"

              description = "Show you Commands of Invite Tracker"

              return emoji, label, description

    @commands.group()

    async def __InviteTracker__(self, ctx: commands.Context):

        """`>invites`, `>addinvites`, `>inviteleaderboard`, `>invitelogging`"""