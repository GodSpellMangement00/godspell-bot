import os

TOKEN = os.environ.get("TOKEN")
NAME = "Zyrox X"
server = "https://discord.gg/codexdev"
ch = "https://discord.com/channels/699587669059174461/1271825678710476911"
OWNER_IDS = [1258831252748894436]
BotName = "Zyrox X"
serverLink = "https://discord.gg/codexdev"